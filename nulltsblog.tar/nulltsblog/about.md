---
layout: page
title: About
---



###Nullts
88年的巨蟹男，伪GEEK，技术是假，宅是真！外表普通，内心二笔和牛逼并存。
闲暇喜欢折腾各种各样的工科玩意，以及阅读各种[杂乱书](http://book.douban.com/people/48982957/).

###硬件&软件
* 本子：ThinkPad-X230
* 爪机：魅族-MX3
* OS：win7 & Centos
* Editer：Vim



### SNS

以下是我的一些SNS的链接和账号，有兴趣fo我或者站内信！

* [豆瓣-不确定二进制](http://www.douban.com/people/48982957/)
* [新浪微博-夏月月鸟手疌](http://weibo.com/nullts)
* [微信-Eureka](weixin.qq.com)

Thanks for reading!

<p class="message">
   除非另有声明，本博客采用 <img style="display:inline;margin-bottom: 0px;" src="http://i.creativecommons.org/l/by-nc-sa/3.0/88x31.png" alt="" width="58" height="20">CC BY-NC-SA 许可协议授权！
</p>
